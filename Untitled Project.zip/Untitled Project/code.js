var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["82055ef5-3856-4a52-90ca-ea32ac206429","93e48b8d-efdf-4700-8fa8-74e59e322f25","1f2801a5-5ce6-4cdd-ae0d-377e573ab6fa","be2bf61c-2d90-492a-88ef-f451e7008c7d","6907f74e-1d1a-435d-99d9-4724cd21614e","4f463b3c-5163-401c-af34-0560aec432b7","1083fc5e-eb1c-42d9-a8c0-9d32abd2e866","735ae4d3-3eb5-4d45-b1be-bf0064125e4d"],"propsByKey":{"82055ef5-3856-4a52-90ca-ea32ac206429":{"name":"ship","sourceUrl":"assets/api/v1/animation-library/gamelab/Sg1jGmj2m99jSXFZrV_VTVULgWnBe91Q/category_vehicles/ship_03.png","frameSize":{"x":376,"y":396},"frameCount":1,"looping":true,"frameDelay":2,"version":"Sg1jGmj2m99jSXFZrV_VTVULgWnBe91Q","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":376,"y":396},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Sg1jGmj2m99jSXFZrV_VTVULgWnBe91Q/category_vehicles/ship_03.png"},"93e48b8d-efdf-4700-8fa8-74e59e322f25":{"name":"ink1","sourceUrl":"assets/api/v1/animation-library/gamelab/RZxIB1TzLq8KxqEkMmaak3ppw9ee5yfv/category_video_games/burst04.png","frameSize":{"x":398,"y":318},"frameCount":1,"looping":true,"frameDelay":2,"version":"RZxIB1TzLq8KxqEkMmaak3ppw9ee5yfv","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":398,"y":318},"rootRelativePath":"assets/api/v1/animation-library/gamelab/RZxIB1TzLq8KxqEkMmaak3ppw9ee5yfv/category_video_games/burst04.png"},"1f2801a5-5ce6-4cdd-ae0d-377e573ab6fa":{"name":"ink2","sourceUrl":"assets/api/v1/animation-library/gamelab/NoHMXwdmldY9LZVfh3RpxscchdU5henz/category_video_games/burst06.png","frameSize":{"x":396,"y":354},"frameCount":1,"looping":true,"frameDelay":2,"version":"NoHMXwdmldY9LZVfh3RpxscchdU5henz","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":354},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NoHMXwdmldY9LZVfh3RpxscchdU5henz/category_video_games/burst06.png"},"be2bf61c-2d90-492a-88ef-f451e7008c7d":{"name":"sea","sourceUrl":"assets/api/v1/animation-library/gamelab/WZ9Eh0Mt6gY_h6uGTwUn_qal4ZBKP8gX/category_backgrounds/bg_underwater_02.png","frameSize":{"x":400,"y":395},"frameCount":1,"looping":true,"frameDelay":2,"version":"WZ9Eh0Mt6gY_h6uGTwUn_qal4ZBKP8gX","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":395},"rootRelativePath":"assets/api/v1/animation-library/gamelab/WZ9Eh0Mt6gY_h6uGTwUn_qal4ZBKP8gX/category_backgrounds/bg_underwater_02.png"},"6907f74e-1d1a-435d-99d9-4724cd21614e":{"name":"octopus","sourceUrl":null,"frameSize":{"x":394,"y":371},"frameCount":1,"looping":true,"frameDelay":12,"version":"qGhRCbiImIMbAnbIruvNVmbrEWR6yVPM","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":371},"rootRelativePath":"assets/6907f74e-1d1a-435d-99d9-4724cd21614e.png"},"4f463b3c-5163-401c-af34-0560aec432b7":{"name":"gameover","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":13,"looping":true,"frameDelay":12,"version":"732__Dan7CMR.JNSS7UL7hjGJblkB_bK","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":1600,"y":1600},"rootRelativePath":"assets/4f463b3c-5163-401c-af34-0560aec432b7.png"},"1083fc5e-eb1c-42d9-a8c0-9d32abd2e866":{"name":"play","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"k6R6i5pWtHuOukHJentnHBZHOAHd4Cb3","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/1083fc5e-eb1c-42d9-a8c0-9d32abd2e866.png"},"735ae4d3-3eb5-4d45-b1be-bf0064125e4d":{"name":"bomb","sourceUrl":"assets/api/v1/animation-library/gamelab/4VzcditYIaaf0.l3_P3qntupPmHANSFg/category_video_games/gameplayobject_item_01.png","frameSize":{"x":346,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"4VzcditYIaaf0.l3_P3qntupPmHANSFg","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":346,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/4VzcditYIaaf0.l3_P3qntupPmHANSFg/category_video_games/gameplayobject_item_01.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var sea = createSprite(200, 200);
sea.setAnimation("sea");

var ink1 = createSprite(200, 200);
ink1.setAnimation("ink1");
ink1.scale = 0.2;
ink1.visible = false;

var ink2 = createSprite(200, 200);
ink2.setAnimation("ink2");
ink2.scale = 0.2;
ink2.visible = false;

var oct = createSprite(200, 55);
oct.setAnimation("octopus");
oct.scale = 0.2;

var ship = createSprite(25, 335);
ship.setAnimation("ship");
ship.scale = 0.15;

var play = createSprite(200, 200);
play.setAnimation("play");
play.scale = 0.5;

var bomb = createSprite(200, 200);
bomb.setAnimation("bomb");
bomb.scale = 0.1;
bomb.visible = false;

var over = createSprite(200, 200);
over.setAnimation("gameover");
over.visible = false;


createEdgeSprites();

function draw() {
  drawSprites();
  if (keyDown("left")) {
    ship.velocityX = -5;
  }
  if (keyDown("right")) {
    ship.velocityX = 5;
  }
  ship.bounceOff(edges);
  oct.bounceOff(edges);
  if (keyDown("up")) {
    bomb.visible = true;
    bomb.x = ship.x;
    bomb.y = ship.y;
    bomb.velocityY = -7.5;
    ink1.visible = true;
    ink2.visible = true;
  }
  if (keyDown("space")) {
    play.visible = false;
    ink2.visible = true;
    ink1.visible = true;
    ink1.velocityY = 7.5;
    ink2.velocityY = 7.5;
    oct.velocityX = 10;
    over.visible = false;
  }
  if (ink1.y > 405) {
    ink1.x = randomNumber(0, 400);
    ink1.y = 0;
    ink1.velocityY = 7.5;
  }
  if (ink2.y > 405) {
    ink2.x = randomNumber(0, 400);
    ink2.y =   0;
    ink2.velocityY = 7.5;
  }
  if (ink1.isTouching(ship)) {
    play.visible = true;
    ink1.velocityY = 0;
    ink2.velocityY = 0;
    if (keyDown("space")) {
      play.visible = false;
    }
  }
  if (ink2.isTouching(ship)) {
    play.visible = true;
    ink1.velocityY = 0;
    ink2.velocityY = 0;
    if (keyDown("space")) {
      play.visible = false;
    }
  }
  if (bomb.isTouching(ink2)) {
    ink2.visible = false;
    if (keyDown("space")) {
      ink1.velocityX = 0;
      ink2.velocityX = 0;
    }
  }
  if (bomb.isTouching(ink1)) {
    ink1.visible = false;
    if (keyDown("space")) {
      play.visible = false;
    }
  }
  if (bomb.isTouching(oct)) {
    over.visible = true;
    if (keyDown("space")) {
      over.visible = false;
    }
  }
  if (play.visible) {
    over.visible = false;
  }
  if (over.visible) {
    play.visible = false;
    ink1.setSpeedAndDirection(0, 0);
    ink2.setSpeedAndDirection(0, 0);
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
